import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import LoginView from '../views/LoginView.vue'
import PerrosView from '../views/PerrosView.vue'
import TiendaView from '../views/TiendaView.vue'
import DonacionView from '../views/DonacionView.vue'



const routes = [
  {
    path: "/",
    name: "LoginView",
    component:LoginView
  },
  {
    path: '/HomeView',
    name: 'Home',
    component: HomeView
  },
  {
    path: '/PerrosView',
    name: 'PerrosView',
    component: PerrosView
  },
  {
    path: '/TiendaView',
    name: 'TiendaView',
    component: TiendaView
  },
  {
    path: '/DonacionView',
    name: 'DonacionView',
    component: DonacionView
  }
  
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router