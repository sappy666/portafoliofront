<template>
    <div id="carouselExampleCaptions" class="carousel slide">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="../assets/3.jpg" class="d-block w-100" alt="">
      <div class="carousel-caption d-none d-md-block">
        <h5>Encuentra a tu mejor amigo</h5>
        <!-- <p>Cambia tu vida</p> -->
      </div>
    </div>
    <div class="carousel-item">
      <img src="../assets/2.jpg" class="d-block w-100" alt="">
      <div class="carousel-caption d-none d-md-block">
        <h5>Cambia su vida</h5>
      </div>
    </div>
    <div class="carousel-item">
      <img src="../assets/1.jpg" class="d-block w-100" alt="">
      <div class="carousel-caption d-none d-md-block">
        <h5>Cambia la tuya</h5>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    <div class="titulo">
    <h2>Animalitos esperando un hogar</h2>
    </div>
    <div class="subtitulo">
    <p>Es una comunidad virtual creada por un equipo de médicos veterinarios dirigida a todos los dueños y amantes de los animales para que puedan compartir sus experiencias y aprender cómo mejorar la calidad de vida de sus mascotas. </p></div>
    <div class="container mt-5">
        <div class="row justify-content-center py-5" v-if="($store.state.perros.length) == 0">
    <div class="col-auto">
    <fade-loader :loading="loading" :color="color" :size="size" class="mb-5"></fade-loader>
    </div>
    </div>
        <div class="row" v-else>
            <div class="col-lg-4 mb-5" v-for="perro in perros" :key="perro.nombre"> 
            <div class=" card border-info mb-3 mx-auto" style="width: 18rem;"  >
                <img :src= "perro.img" class="card-img-top" alt="img">
                <div class="card-body">
                    <h5 class="card-title text-center">{{perro.nombre}}</h5>
                    <p class="card-text text-center">{{perro.descripcion}}</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">Genero: {{perro.genero  }}</li>
                    <li class="list-group-item">Tamaño: {{perro.tamaño }}</li>
                </ul>
                <button class=" btnInscribir p-2">Adoptar</button>
            </div>
        </div>
    </div>
    </div>
</template>
    
    
    <script>
    import FadeLoader from 'vue-spinner/src/FadeLoader.vue'
    import {mapActions, mapState} from 'vuex' 

    export default {
        name: "Home-View",
        data() {
            return {
            color:'#d676ab'
        }
        },

        components: {
            FadeLoader
        }, 

        created(){
            this.getPerros()
        },

        methods: {
            ...mapActions(['getPerros'])
        },

        computed : {
            ...mapState(['perros'])
        },

        showAlert(texto1, texto2){
            Swal.fire({
                title:texto1,
                text: texto2,
                icon: 'success',
                confirmButtonText: 'Ok'
            })
        },

        async mounted(){
            this.$store.state.perros=[]
            if(this.$store.state.usuarioConectado===''){    
                this.showAlert('No hay usuario conectado', 'Debe loguearse')
                this.$router.push('/login')
            }
        }
    }
    
    </script>
    
<style>
.carousel-item{
    height: 600px;
}
.carousel-item img{
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.carousel-caption{
    background-color: rgba(0, 0, 0, 0.385);
    border-radius: 1rem;
    max-width: 500px;
    margin-inline: auto;
    margin-bottom: 150px;
}
.carousel-item h5{
    font-family: 'Montserrat', sans-serif;
    font-size: 42px;
}
.carousel-item p{
    font-family: 'Montserrat', sans-serif;
    font-size: 18px;
}

        .titulo{
        text-align: center;
        font-family: 'Montserrat', sans-serif;
        }

        .subtitulo{
        text-align: center;
        font-family: 'Montserrat', sans-serif;
        font-size: 18px;
        padding-inline: 15rem ;
        }

        .card{
            font-family: 'Montserrat', sans-serif;
        }

        .card-img-top{
        max-width: 8rem;
        height: 160px;
        align-self: center;
        padding-top: 2rem;
        }

        .card-body{
        padding-top: 7rem;
        }

        .btn--ver{
        background-color: #EA4C89;
        border-radius: 8px;
        border-style: none;
        box-sizing: border-box;
        color: #FFFFFF;
        cursor: pointer;
        display: inline-block;
        font-size: 14px;
        font-weight: 500;
        height: 40px;
        line-height: 20px;
        margin-top: auto;
        text-align: center;
        transition: color 100ms;
        touch-action: manipulation;
        font-family: 'Montserrat', sans-serif;
        }

        .btnInscribir {
            background-color: #71c3d7;
            color: white;
            border: 1px solid #71c3d7;
            letter-spacing: 3px;
        }

        .btnInscribir:hover{
            background-color: #f082bf;
        }


    </style>