<template>
  <div class="titulo">
<H2>Dona Ahora</H2></div>
<div class="container">
  <div class="card-donacion">
    <!-- alert component     -->
    <div class="alert-wrapper">
      <div class="alert">
        Aún necesitamos $167.000
      </div>
    </div>

    <div class="main-section">
      <div class="progress-bar"></div>
      <!-- main section container -->
      <div class="container">
        <div class="notice"><span class="highlight">Solo 15 días</span>
          para recaudar fondos
        </div>
        <div class="description">únete a los <span class="highlight">42</span>
          donantes que ya han ayudado a la gatita "Nini"
        </div>
        <!-- donate form -->
        <div class="form">
          <span class="currency">$</span>
          <input type="text" value="5000" class="form-item amount-input">
          <button class="form-item btn">Donar ahora</button>
        </div>
        <!-- end of donate form -->
        <a href="#">Sitio oficial</a>
      </div>
      <!-- end of main section container -->
    </div>
    <div class="card-footer">
      <button>Guardar</button>
      <button>Compartir</button>
    </div>
  </div>
</div>
</template>
    
    
    <script>
    export default {
    name: "Home-View",
      
    }
    
    </script>
    
  <style>
  button,
  input {
    border: none;
    outline: none;
  }

  button {
    cursor: pointer;
    transition: box-shadow 0.4s;
  }

  button:hover {
    box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.1);
  }

  a {
    /* font-family: 'Itim', cursive; */
    text-decoration: none;
    margin: 10px 0;
  }

  /* fin globales */

  /* common styles */
  .main-section,
  .progress-bar,
  .form input,
  .card-footer button {
    border: 1px solid #e0dfdf;
  }

  .container,
  .form,
  .card-footer {
    display: flex;
  }

  /* end of common styles */

  .container {
    width: 100%;
    justify-content: center;
    padding: 20px 0;
  }

  .card-donacion {
    width: 20rem;
  }

  .card-donacion .alert {
    background-color: #424242;
    text-align: center;
    color: #fafafa;
    padding: 18px 25px;
    border-radius: 3px;
    position: relative;
  }

  /* creates the alert arrow */
  .card-donacion .alert::after {
    content: "";
    width: 0.5em;
    height: 0.5em;
    box-sizing: border-box;
    position: absolute;
    bottom: 0;
    right: 1.5em;
    border-color: #424242 transparent transparent transparent;
    border-width: 0.5em;
    border-style: solid;
    transform: translateY(1em);
  }

  .card-donacion .main-section {
    margin: 15px auto;
  }

  .card-donacion .main-section .progress-bar {
    background-color: #fafafa;
    height: 14px;
    position: relative;
  }

  .card-donacion .main-section .progress-bar::before {
    content: "";
    height: 100%;
    width: 75%;
    background-color: #ff74ef;
    position: absolute;
    left: 0;
  }

  .highlight {
    font-weight: bold;
  }

  .main-section .container {
    flex-direction: column;
    justify-content: start;
    width: 90%;
    margin: auto;
    color: #878787;
  }

  .main-section .container .notice .highlight {
    color: #ab33f1;
  }

  .main-section .container .description {
    margin: 25px 0;
  }

  .main-section .container .form {
    position: relative;
    justify-content: space-between;
  }

  .main-section .container .form .currency {
    position: absolute;
    top: 25%;
    font-size: 1.4rem;
    margin-left: 0.5rem;
    font-weight: bold;
  }

  .main-section .container .form .form-item {
    width: 8.3rem;
    height: 60px;
    border-radius: 3px;
  }

  .main-section .container .form input {
    box-sizing: border-box;

    padding-left: 1.5rem;
    font-weight: bolder;
    font-size: 1.4rem;
  }

  .main-section .container .form .btn {
    background-color: #ab33f1;
    color: #fafafa;
    font-size: 1.4rem;
  }

  .carta-donacion .card-footer {
    justify-content: space-between;
  }

  .carta-donacion .card-footer button {
    border-radius: 3px;
    height: 40px;
    width: 9.3rem;
    background-color: #fafafa;
    color: #878787;
    font-weight: 400;
  }
    .titulo{
    text-align: center;
    font-family: 'Montserrat', sans-serif;
    }
    .subtitulo{
    text-align: center;
    font-family: 'Montserrat', sans-serif;
    font-size: 18px;
    padding-inline: 15rem ;
    }
    </style>