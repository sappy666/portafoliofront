<template> 
    <div class="navbar">
        <div class="container-fluid d-flex align-items-center">
            <div class="me-5 py-4 px-5">
                <img src="../assets/logo.png" alt="" width="60">
            </div>
            <div class="d-flex flex-column" v-if="(loginTrue)">
            <p class="mb-0 ms-4"> ¡Bienvenido!</p>                
            <p class="mb-0"> {{$store.state.usuarioConectado}}</p>
            </div>
            <!-- <div id="logo">
                <a v-on:click="HomePage"><img src="../assets/logo.png" alt="" width="250"></a>
            </div> -->
            <div class="d-flex ms-auto me-3">
                <nav>
                    <ul id="list-contenedor" class="d-flex justify-content-around align-items-center">
                        <router-link class="link-nav px-3" to="/HomeView" v-if="(loginTrue)">Inicio</router-link>
                        <router-link class="link-nav px-3" to="/PerrosView" v-if="(loginTrue)">Adopta</router-link>
                        <router-link class="link-nav px-3" to="/TiendaView" v-if="(loginTrue)">Tienda</router-link>
                        <router-link class="link-nav px-3" to="/DonacionView" v-if="(loginTrue)">Dona</router-link>
                        <router-link class="link-nav px-3" to="/" v-if="(!loginTrue)">Login</router-link>
                        <button type="button" class="btn-logout" data-bs-toggle="modal" data-bs-target="#exampleModal" v-if="(loginTrue)">
                        Logout
                        </button>
                        <!-- <p class="mb-0">{{usuarioConectado}}</p> -->
                    
                    </ul>   
                </nav>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Logout</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          ¿Esta seguro que desea cerrar la sesión?
          <p>{{$store.state.usuarioConectado}}</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-no" data-bs-dismiss="modal">No</button>
          <button type="button" v-on:click="logout" class="btn btn-si" data-bs-dismiss="modal">Si</button>
        </div>
      </div>
    </div>
    </div>
    </template>
        
    <script>

    import { mapGetters, mapMutations } from 'vuex';
    import { auth } from "@/auth/auth.service";

    export default {
        name: 'NavBar',
         computed:{
        ...mapGetters(['loginTrue']),
         },
        methods:{
            ...mapMutations(['cambiaEstadoLoginFalse']),
            async logout() {
                try {
                    await auth.signOut();
                    this.$store.state.cursos=[]
                    this.$store.state.usuarioConectado=''
                    this.cambiaEstadoLoginFalse();
                    this.$router.push('/');
                    
                } catch(error){
                    console.log(error)
                }
            }
        }
    };

    </script>
<style>
#login{
    cursor: pointer;
}
.navbar{
    list-style-type: none;
    background-color: #DAB6FC;
    color: azure;
    padding: .5rem 2rem;
    font-size: 16px;
    margin: 0%;
    font-family: 'Montserrat', sans-serif;
}
.link-nav{
    text-decoration: none;
    color: azure;
    transition: all 0.5s ease;
}
.link-nav:hover{
    color: #F57ED2;
    transform: scale(1.2);
}
.list-item{
    cursor: pointer;
}
.btn-logout{
    text-decoration: none;
    color: azure;
    border: none;
    transition: all 0.5s ease;
    background-color: #F57ED2;
}
.btn-logout:hover{
    transform: scale(1.2);
}
.btn.btn-no{
    background-color: #82daf0;
    color: azure;
}
.btn.btn-no:hover{
    background-color: #71c3d7;
    color: azure;
}
.btn.btn-si{
    background-color: #f082bf;
    color: azure;
}
.btn.btn-si:hover{
    background-color: #d676ab;
    color: azure;
}
#exampleModal{
    font-family: 'Montserrat', sans-serif;
}
</style>